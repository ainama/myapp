var mysql_config = {
  host     : 'bdm236195480.my3w.com',
  user     : 'bdm236195480',
  password : 'bdm236195480',
  database : 'bdm236195480_db',
  port: '3306'
};

module.exports = mysql_config;
