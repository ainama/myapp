var config = {
  host     : '47.95.194.249',
  user     : 'communityDB',
  password : 'communityDB',
  database : 'communityDB',
  port: '3306'
};

module.exports = config;
